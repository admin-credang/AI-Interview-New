import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api from "../api";


/*
 * ============================================================
 * INTERVIEW SESSION
 * ============================================================
 *
 * MONITORING
 *
 * Camera
 *   -> Controls camera stream
 *
 * Face Detection
 *   -> Controls MediaPipe face detection
 *
 * Eye / Gaze Detection
 *   -> Controls eye/gaze processing
 *
 * Dependency:
 *
 * Camera OFF
 *   -> Face OFF
 *   -> Eye OFF
 *
 * Face OFF
 *   -> Eye OFF
 *
 * Eye ON
 *   -> Camera ON
 *   -> Face ON
 *
 * Interview flow is independent from monitoring.
 *
 * Q1 -> Answer -> Follow-up/Next
 * Q2 -> Answer -> Follow-up/Next
 * Q3 -> Answer -> Follow-up/Next
 * Q4 -> Answer -> Follow-up/Next
 * Q5 -> Complete
 *
 * ============================================================
 */

/*
 * ============================================================
 * HELPERS
 * ============================================================
 */

function isTrue(value) {
  if (typeof value === "boolean") {
    return value;
  }

  if (typeof value === "number") {
    return value === 1;
  }

  if (typeof value === "string") {
    return [
      "true",
      "1",
      "yes",
      "y",
    ].includes(value.trim().toLowerCase());
  }

  return false;
}

function normalizeAction(value) {
  if (!value) {
    return "";
  }

  return String(value)
    .trim()
    .toLowerCase()
    .replace(/[\s-]+/g, "_");
}

function getParameterSources(data) {
  return [
    data?.parameters,
    data?.sessionInfo?.parameters,
    data?.session_info?.parameters,
    data?.data?.parameters,
    data?.result?.parameters,
    data?.response?.parameters,
  ].filter(
    (value) =>
      value &&
      typeof value === "object" &&
      !Array.isArray(value)
  );
}

function getMergedParameters(data) {
  const sources = getParameterSources(data);

  return Object.assign({}, ...sources);
}

function normalizeValue(value) {
  if (
    value === null ||
    value === undefined
  ) {
    return null;
  }

  if (typeof value === "string") {
    const trimmed = value.trim();
    return trimmed || null;
  }

  if (
    typeof value === "number" ||
    typeof value === "boolean"
  ) {
    return value;
  }

  if (Array.isArray(value)) {
    return value
      .map((item) => normalizeValue(item))
      .filter(
        (item) =>
          item !== null &&
          item !== undefined &&
          item !== ""
      );
  }

  if (typeof value === "object") {
    return (
      normalizeValue(value.value) ??
      normalizeValue(value.text) ??
      normalizeValue(value.answer) ??
      normalizeValue(value.question) ??
      null
    );
  }

  return String(value);
}

function normalizeQuestion(
  rawQuestion,
  fallback = {}
) {
  if (!rawQuestion) {
    return null;
  }

  if (typeof rawQuestion === "string") {
    const questionText =
      rawQuestion.trim();

    if (!questionText) {
      return null;
    }

    return {
      id:
        fallback.id ||
        fallback.question_id ||
        fallback.questionId ||
        null,

      question: questionText,

      question_number:
        Number(
          fallback.question_number ??
            fallback.questionNumber ??
            1
        ) || 1,

      question_type:
        fallback.question_type ||
        fallback.questionType ||
        "technical",

      category:
        fallback.category ||
        "technical",

      difficulty:
        fallback.difficulty ||
        null,

      is_follow_up: isTrue(
        fallback.is_follow_up ??
          fallback.isFollowUp
      ),

      parent_question_id:
        fallback.parent_question_id ||
        fallback.parentQuestionId ||
        null,
    };
  }

  const questionText = String(
    rawQuestion.question ||
      rawQuestion.text ||
      rawQuestion.question_text ||
      rawQuestion.questionText ||
      ""
  ).trim();

  if (!questionText) {
    return null;
  }

  return {
    id:
      rawQuestion.id ||
      rawQuestion.question_id ||
      rawQuestion.questionId ||
      fallback.id ||
      fallback.question_id ||
      fallback.questionId ||
      null,

    question: questionText,

    question_number:
      Number(
        rawQuestion.question_number ??
          rawQuestion.questionNumber ??
          fallback.question_number ??
          fallback.questionNumber ??
          1
      ) || 1,

    question_type:
      rawQuestion.question_type ||
      rawQuestion.questionType ||
      fallback.question_type ||
      fallback.questionType ||
      "technical",

    category:
      rawQuestion.category ||
      fallback.category ||
      "technical",

    difficulty:
      rawQuestion.difficulty ||
      fallback.difficulty ||
      null,

    is_follow_up: isTrue(
      rawQuestion.is_follow_up ??
        rawQuestion.isFollowUp ??
        fallback.is_follow_up ??
        fallback.isFollowUp
    ),

    parent_question_id:
      rawQuestion.parent_question_id ||
      rawQuestion.parentQuestionId ||
      fallback.parent_question_id ||
      fallback.parentQuestionId ||
      null,
  };
}

/*
 * ============================================================
 * FACE / EYE HELPERS
 * ============================================================
 */

function distance(a, b) {
  if (!a || !b) {
    return 0;
  }

  return Math.sqrt(
    Math.pow(a.x - b.x, 2) +
      Math.pow(a.y - b.y, 2)
  );
}

function calculateEyeAspectRatio(
  top,
  bottom,
  left,
  right
) {
  const vertical = distance(
    top,
    bottom
  );

  const horizontal = distance(
    left,
    right
  );

  if (!horizontal) {
    return 0;
  }

  return vertical / horizontal;
}

function calculateIrisPosition(
  irisPoints,
  leftCorner,
  rightCorner
) {
  if (
    !irisPoints ||
    irisPoints.length === 0 ||
    !leftCorner ||
    !rightCorner
  ) {
    return 0.5;
  }

  const center =
    irisPoints.reduce(
      (acc, point) => ({
        x: acc.x + point.x,
        y: acc.y + point.y,
      }),
      {
        x: 0,
        y: 0,
      }
    );

  center.x /=
    irisPoints.length;

  center.y /=
    irisPoints.length;

  const width =
    rightCorner.x -
    leftCorner.x;

  if (
    Math.abs(width) <
    0.0001
  ) {
    return 0.5;
  }

  return (
    (center.x -
      leftCorner.x) /
    width
  );
}

/*
 * ============================================================
 * COMPONENT
 * ============================================================
 */

/*
 * ============================================================
 * VOICE YES / NO PARSER (used for the follow-up offer)
 * ============================================================
 * Returns "yes", "no" or null (could not understand).
 */
/*
 * ============================================================
 * MONITORING THRESHOLDS  (tune these without touching the logic)
 * ============================================================
 */
const MEDIAPIPE_WASM_URL =
  "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision/wasm";

// Phone detection (MediaPipe object detector, COCO "cell phone")
const PHONE_MODEL_URL =
  "https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite0/float16/1/efficientdet_lite0.tflite";
const PHONE_SCORE_THRESHOLD = 0.4; // min confidence for a phone
const PHONE_CHECK_INTERVAL_MS = 600; // run detector ~1.5x per second
const PHONE_TERMINATE_MS = 3000; // phone must stay visible this long
const PHONE_GRACE_MS = 1500; // tolerate missed frames before resetting

// Looking down (eye-ball movement, via MediaPipe blendshapes)
const LOOK_DOWN_SCORE = 0.5; // 0..1, average of both eyes
const LOOK_DOWN_EPISODE_MS = 1000; // one "glance down" = at least this long
const LOOK_DOWN_TERMINATE_MS = 4000; // one long continuous look down
const LOOK_DOWN_REPEAT_COUNT = 4; // this many glances ...
const LOOK_DOWN_REPEAT_WINDOW_MS = 90000; // ... within this window

const GREETING_SPEECH =
  "Hello! Welcome to the AI Interview. I will guide you through the interview and ask you a series of questions based on your interview configuration. Are you ready to start your interview?";

const CLOSING_SPEECH =
  "Thank you. Your interview is complete. The interviewer will review your answers.";

const YES_WORDS =
  /\b(yes|yeah|yep|yup|yea|sure|ok|okay|please|definitely|absolutely|go ahead|of course|ask)\b/i;
const NO_WORDS =
  /\b(no|nope|nah|not|skip|next|don'?t|do not|no thanks|no thank you)\b/i;

const parseYesNo = (text) => {
  const spoken = String(text || "").trim();
  if (!spoken) return null;
  const yes = YES_WORDS.test(spoken);
  const no = NO_WORDS.test(spoken);
  if (yes && !no) return "yes";
  if (no && !yes) return "no";
  return null;
};

export default function InterviewSession() {
  const {
    interviewId,
    sessionId,
  } = useParams();

  const navigate =
    useNavigate();

  /*
   * ============================================================
   * INTERVIEW STATE
   * ============================================================
   */

  const [phase, setPhase] =
    useState("greeting");

  // becomes true when the candidate says / clicks "Yes"
  const [ready, setReady] =
    useState(false);

  // chat transcript shown on the right side ("Previous Questions")
  const [chatLog, setChatLog] =
    useState([]);

  const chatEndRef = useRef(null);

  // how many characters of the current question are shown so far
  // (the text appears gradually while the AI voice is speaking)
  const [typedLength, setTypedLength] =
    useState(0);

  // attaches the running camera stream as soon as <video> is mounted
  const attachVideo = useCallback((element) => {
    videoRef.current = element;

    if (
      element &&
      streamRef.current &&
      element.srcObject !== streamRef.current
    ) {
      element.srcObject = streamRef.current;
      element.play().catch(() => {});
    }
  }, []);

  const [
    currentQuestion,
    setCurrentQuestion,
  ] = useState(null);

  const [
    questionNumber,
    setQuestionNumber,
  ] = useState(1);

  const [answer, setAnswer] =
    useState("");

  const [
    lastAnswer,
    setLastAnswer,
  ] = useState("");

  const [error, setError] =
    useState("");

  const [
    processing,
    setProcessing,
  ] = useState(false);

  const [
    elapsedSeconds,
    setElapsedSeconds,
  ] = useState(0);

  const [
    followUpQuestion,
    setFollowUpQuestion,
  ] = useState(null);

  const [
    followUpConfirmation,
    setFollowUpConfirmation,
  ] = useState(false);

  /*
   * ============================================================
   * VOICE STATE
   * ============================================================
   */

  const [
    isListening,
    setIsListening,
  ] = useState(false);

  const [
    isSpeaking,
    setIsSpeaking,
  ] = useState(false);

  const [
    voiceSupported,
    setVoiceSupported,
  ] = useState(false);

  const [
    autoSubmitVoice,
    setAutoSubmitVoice,
  ] = useState(false);

  /*
   * ============================================================
   * MONITORING STATE
   * ============================================================
   */

  const [
    cameraEnabled,
    setCameraEnabled,
  ] = useState(false);

  const [
    faceDetectionEnabled,
    setFaceDetectionEnabled,
  ] = useState(false);

  const [
    eyeGazeEnabled,
    setEyeGazeEnabled,
  ] = useState(false);

  const [
    faceStatus,
    setFaceStatus,
  ] = useState(
    "Face detection OFF"
  );

  const [
    eyeStatus,
    setEyeStatus,
  ] = useState(
    "Eye/Gaze detection OFF"
  );

  const [
    monitoringReady,
    setMonitoringReady,
  ] = useState(false);

  /*
   * Monitoring policy chosen by the INTERVIEWER.
   *
   * enabled = false -> no camera, no face, no eye. The
   *                    interview works normally.
   * enabled = true  -> camera starts automatically and the
   *                    candidate cannot switch it off.
   */
  const [policy, setPolicy] =
    useState({
      loaded: false,
      enabled: false,
      face: false,
      eye: false,
      phone: false,
    });

  const [
    phoneStatus,
    setPhoneStatus,
  ] = useState(
    "Phone detection OFF"
  );

  const [
    cameraBlocked,
    setCameraBlocked,
  ] = useState(false);

  const autoStartedRef =
    useRef(false);

  /*
   * Monitoring events are saved for the interviewer.
   * Each type is sent at most once every 15 seconds.
   */
  const eventThrottleRef =
    useRef({});

  const logMonitoringEventRef =
    useRef(null);

  logMonitoringEventRef.current =
    (type) => {
      if (!sessionId) {
        return;
      }

      const now = Date.now();

      if (
        now -
          (eventThrottleRef
            .current[type] || 0) <
        15000
      ) {
        return;
      }

      eventThrottleRef.current[
        type
      ] = now;

      api
        .post(
          `/hiring/sessions/${sessionId}/monitoring-event`,
          { type }
        )
        .catch(() => {});
    };

  /*
   * ============================================================
   * REFS
   * ============================================================
   */

  const mountedRef =
    useRef(true);

  const processingRef =
    useRef(false);

  const completedRef =
    useRef(false);

  const terminatedRef =
    useRef(false);

  const currentQuestionRef =
    useRef(null);

  const recognitionRef =
    useRef(null);

  const streamRef =
    useRef(null);

  const videoRef =
    useRef(null);

  const speechGenerationRef =
    useRef(0);

  const submitAnswerRef =
    useRef(null);

  // Voice follow-up confirmation helpers
  const phaseRef =
    useRef("");

  const followUpYesRef =
    useRef(null);

  const followUpNoRef =
    useRef(null);

  const startListeningRef =
    useRef(null);

  const confirmRetryRef =
    useRef(0);

  const speakThenRef =
    useRef(null);

  /*
   * ============================================================
   * MEDIAPIPE REFS
   * ============================================================
   */

  const faceLandmarkerRef =
    useRef(null);

  const monitoringFrameRef =
    useRef(null);

  const monitoringRunningRef =
    useRef(false);

  const noFaceSinceRef =
    useRef(null);

  const multipleFaceSinceRef =
    useRef(null);

  const eyesClosedSinceRef =
    useRef(null);

  const lookingAwaySinceRef =
    useRef(null);

  // Looking down (phone / notes below the camera)
  const lookDownSinceRef =
    useRef(null);

  const lookDownCountedRef =
    useRef(false);

  const downEpisodesRef =
    useRef([]);

  // Phone detection
  const objectDetectorRef =
    useRef(null);

  const phoneSinceRef =
    useRef(null);

  const phoneLastSeenRef =
    useRef(0);

  /*
   * ============================================================
   * TERMINATION REF
   * ============================================================
   */

  const terminateInterviewRef =
    useRef(null);

  /*
   * ============================================================
   * STOP MEDIA
   * ============================================================
   */

  const stopMedia =
    useCallback(() => {
      /*
       * Stop speech recognition
       */
      if (
        recognitionRef.current
      ) {
        try {
          recognitionRef.current.stop();
        } catch {}
      }

      /*
       * Stop camera
       */
      if (streamRef.current) {
        streamRef.current
          .getTracks()
          .forEach((track) => {
            try {
              track.stop();
            } catch {}
          });

        streamRef.current = null;
      }

      /*
       * Clear video
       */
      if (videoRef.current) {
        try {
          videoRef.current.pause();
        } catch {}

        videoRef.current.srcObject =
          null;
      }

      /*
       * Stop TTS
       */
      window.speechSynthesis?.cancel();

      /*
       * Stop monitoring loop
       */
      if (
        monitoringFrameRef.current
      ) {
        cancelAnimationFrame(
          monitoringFrameRef.current
        );

        monitoringFrameRef.current =
          null;
      }

      monitoringRunningRef.current =
        false;

      /*
       * Reset timers
       */
      noFaceSinceRef.current =
        null;

      multipleFaceSinceRef.current =
        null;

      eyesClosedSinceRef.current =
        null;

      lookingAwaySinceRef.current =
        null;

      lookDownSinceRef.current =
        null;

      lookDownCountedRef.current =
        false;

      downEpisodesRef.current =
        [];

      phoneSinceRef.current =
        null;

      phoneLastSeenRef.current =
        0;

      /*
       * Disable states
       */
      setCameraEnabled(false);

      setFaceDetectionEnabled(false);

      setEyeGazeEnabled(false);

      setFaceStatus(
        "Face detection OFF"
      );

      setEyeStatus(
        "Eye/Gaze detection OFF"
      );
    }, []);

  /*
   * ============================================================
   * TERMINATE INTERVIEW
   * ============================================================
   */

  const terminateInterview =
    useCallback(
      async (reason) => {
        if (
          completedRef.current ||
          terminatedRef.current
        ) {
          return;
        }

        terminatedRef.current =
          true;

        processingRef.current =
          false;

        stopMedia();

        if (
          mountedRef.current
        ) {
          setProcessing(false);
          setPhase("terminated");
        }

        console.warn(
          "INTERVIEW TERMINATED:",
          reason
        );

        try {
          await api.post(
            "/interview-monitoring/terminate",
            {
              session_id:
                sessionId,
              reason,
            }
          );

          console.log(
            "Termination saved successfully."
          );
        } catch (err) {
          console.error(
            "Termination API failed:",
            err
          );
        }
      },
      [
        sessionId,
        stopMedia,
      ]
    );

  terminateInterviewRef.current =
    terminateInterview;

  /*
   * ============================================================
   * TAB / PAGE LEAVE
   * ============================================================
   */

  useEffect(() => {
    if (!sessionId) {
      return;
    }

    const anyMonitoringEnabled =
      cameraEnabled ||
      faceDetectionEnabled ||
      eyeGazeEnabled;

    if (!anyMonitoringEnabled) {
      return;
    }

    const handleVisibilityChange =
      () => {
        if (!document.hidden) {
          return;
        }

        if (
          completedRef.current ||
          terminatedRef.current
        ) {
          return;
        }

        terminateInterviewRef.current?.(
          "candidate_left_interview_page"
        );
      };

    document.addEventListener(
      "visibilitychange",
      handleVisibilityChange
    );

    return () => {
      document.removeEventListener(
        "visibilitychange",
        handleVisibilityChange
      );
    };
  }, [
    sessionId,
    cameraEnabled,
    faceDetectionEnabled,
    eyeGazeEnabled,
  ]);

  /*
   * ============================================================
   * TIMER
   * ============================================================
   */

  useEffect(() => {
    if (phase !== "question") {
      return;
    }

    const timer =
      setInterval(() => {
        setElapsedSeconds(
          (previous) =>
            previous + 1
        );
      }, 1000);

    return () => {
      clearInterval(timer);
    };
  }, [phase]);

  /*
   * ============================================================
   * MOUNT / UNMOUNT
   * ============================================================
   */

  useEffect(() => {
    mountedRef.current = true;

    return () => {
      mountedRef.current = false;

      stopMedia();

      if (
        faceLandmarkerRef.current
      ) {
        try {
          faceLandmarkerRef.current.close();
        } catch {}

        faceLandmarkerRef.current =
          null;
      }
    };
  }, [stopMedia]);

  /*
   * ============================================================
   * TEXT TO SPEECH
   * ============================================================
   */

  const speakQuestion =
    useCallback(
      (text) => {
        if (
          !text ||
          !window.speechSynthesis
        ) {
          return;
        }

        speechGenerationRef.current +=
          1;

        const generation =
          speechGenerationRef.current;

        window.speechSynthesis.cancel();

        const utterance =
          new SpeechSynthesisUtterance(
            text
          );

        utterance.rate = 0.95;
        utterance.pitch = 1;
        utterance.volume = 1;

        utterance.onstart = () => {
          if (
            mountedRef.current &&
            generation ===
              speechGenerationRef.current
          ) {
            setIsSpeaking(true);
          }
        };

        utterance.onend = () => {
          if (
            mountedRef.current &&
            generation ===
              speechGenerationRef.current
          ) {
            setIsSpeaking(false);
          }
        };

        utterance.onerror = () => {
          if (
            mountedRef.current &&
            generation ===
              speechGenerationRef.current
          ) {
            setIsSpeaking(false);
          }
        };

        window.speechSynthesis.speak(
          utterance
        );
      },
      []
    );

  /*
   * ============================================================
   * SHOW QUESTION
   * ============================================================
   */

  const showQuestion =
    useCallback(
      (rawQuestion) => {
        const question =
          normalizeQuestion(
            rawQuestion
          );

        if (
          !question ||
          !question.question
        ) {
          setError(
            "Invalid question received from server."
          );

          setProcessing(false);

          return;
        }

        console.log(
          "DISPLAYING QUESTION:",
          question
        );

        currentQuestionRef.current =
          question;

        setCurrentQuestion(
          question
        );

        setQuestionNumber(
          Number(
            question.question_number
          ) || 1
        );

        setAnswer("");

        setLastAnswer("");

        setFollowUpQuestion(null);

        setFollowUpConfirmation(
          false
        );

        setError("");

        setProcessing(false);

        setPhase("question");

        if (
          recognitionRef.current
        ) {
          try {
            recognitionRef.current.stop();
          } catch {}
        }

        speakQuestion(
          question.question
        );
      },
      [speakQuestion]
    );

  /*
   * ============================================================
   * COMPLETE INTERVIEW
   * ============================================================
   */

  const completeInterview =
    useCallback(() => {
      if (
        completedRef.current ||
        terminatedRef.current
      ) {
        return;
      }

      completedRef.current =
        true;

      processingRef.current =
        false;

      stopMedia();

      setProcessing(false);

      setPhase("completed");

      // spoken thank-you
      try {
        window.speechSynthesis?.cancel();
        window.speechSynthesis?.speak(
          new SpeechSynthesisUtterance(CLOSING_SPEECH)
        );
      } catch {}

      // Thank-you email + "we will contact you if selected".
      // The candidate does not get a report or scores.
      api
        .post(
          `/hiring/sessions/${sessionId}/submitted`
        )
        .catch((err) => {
          console.warn(
            "Submit confirmation failed:",
            err
          );
        });
    }, [
      interviewId,
      sessionId,
      navigate,
      stopMedia,
    ]);

  /*
   * ============================================================
   * FOLLOW-UP EXTRACTION
   * ============================================================
   */

  const extractFollowUpQuestion =
    useCallback(
      (
        data,
        parameters
      ) => {
        const candidates = [
          parameters?.follow_up_question,
          parameters?.followUpQuestion,
          parameters?.follow_up_question_text,
          parameters?.followUpQuestionText,
          data?.follow_up_question,
          data?.followUpQuestion,
          data?.follow_up_question_text,
          data?.followUpQuestionText,
          data?.result?.follow_up_question,
          data?.data?.follow_up_question,
          data?.response?.follow_up_question,
        ];

        for (
          const candidate of candidates
        ) {
          const normalized =
            normalizeValue(candidate);

          if (
            typeof normalized ===
              "string" &&
            normalized.trim()
          ) {
            return normalized.trim();
          }
        }

        return null;
      },
      []
    );

  /*
   * ============================================================
   * NEXT QUESTION EXTRACTION
   * ============================================================
   */

  const extractNextQuestion =
    useCallback(
      (
        data,
        parameters
      ) => {
        const rawNextQuestion =
          parameters?.next_question ||
          parameters?.nextQuestion ||
          data?.next_question ||
          data?.nextQuestion ||
          data?.result?.next_question ||
          data?.result?.nextQuestion ||
          data?.data?.next_question ||
          data?.response?.next_question ||
          null;

        if (rawNextQuestion) {
          return normalizeQuestion(
            rawNextQuestion
          );
        }

        const directQuestion =
          parameters?.question ||
          data?.question;

        if (!directQuestion) {
          return null;
        }

        return normalizeQuestion({
          id:
            parameters?.question_id ||
            parameters?.questionId ||
            data?.question_id ||
            data?.questionId ||
            null,

          question:
            directQuestion,

          question_number:
            parameters?.question_number ??
            parameters?.questionNumber ??
            data?.question_number ??
            data?.questionNumber ??
            1,

          category:
            parameters?.category ||
            data?.category ||
            "technical",

          difficulty:
            parameters?.difficulty ||
            data?.difficulty ||
            null,

          question_type:
            parameters?.question_type ||
            parameters?.questionType ||
            data?.question_type ||
            data?.questionType ||
            "technical",

          is_follow_up:
            parameters?.is_follow_up ??
            parameters?.isFollowUp ??
            data?.is_follow_up ??
            data?.isFollowUp ??
            false,

          parent_question_id:
            parameters?.parent_question_id ||
            parameters?.parentQuestionId ||
            data?.parent_question_id ||
            data?.parentQuestionId ||
            null,
        });
      },
      []
    );

  /*
   * ============================================================
   * HANDLE DIALOGFLOW RESPONSE
   * ============================================================
   */

  const handleDialogflowResponse =
    useCallback(
      (responseData) => {
        if (!responseData) {
          throw new Error(
            "Empty response from backend."
          );
        }

        const data =
          responseData?.data &&
          typeof responseData.data ===
            "object"
            ? responseData.data
            : responseData;

        const parameters =
          getMergedParameters(data);

        const nextAction =
          normalizeAction(
            parameters?.next_action ??
              parameters?.nextAction ??
              data?.next_action ??
              data?.nextAction
          );

        console.log(
          "NEXT ACTION:",
          nextAction
        );

        /*
         * COMPLETION
         */

        const completed =
          isTrue(
            parameters?.completed
          ) ||
          isTrue(
            parameters?.interview_completed
          ) ||
          isTrue(
            parameters?.interviewCompleted
          ) ||
          isTrue(
            data?.completed
          ) ||
          isTrue(
            data?.interview_completed
          ) ||
          isTrue(
            data?.interviewCompleted
          ) ||
          nextAction === "complete" ||
          nextAction === "completed";

        if (completed) {
          completeInterview();
          return;
        }

        /*
         * FOLLOW-UP REQUIRED
         */

        const followUpRequired =
          isTrue(
            parameters?.follow_up_required
          ) ||
          isTrue(
            parameters?.followUpRequired
          ) ||
          isTrue(
            parameters?.is_follow_up_required
          ) ||
          isTrue(
            parameters?.isFollowUpRequired
          ) ||
          isTrue(
            data?.follow_up_required
          ) ||
          isTrue(
            data?.followUpRequired
          );

        /*
         * FOLLOW-UP CONFIRMATION
         */

        if (
          followUpRequired &&
          (
            nextAction ===
              "ask_follow_up_confirmation" ||
            nextAction ===
              "follow_up_confirmation"
          )
        ) {
          const generatedFollowUp =
            extractFollowUpQuestion(
              data,
              parameters
            );

          if (!generatedFollowUp) {
            setError(
              "Follow-up question was not received from server."
            );

            setProcessing(false);

            return;
          }

          setFollowUpQuestion(
            generatedFollowUp
          );

          setFollowUpConfirmation(
            true
          );

          setProcessing(false);

          setPhase(
            "followup-confirmation"
          );

          return;
        }

        /*
         * DIRECT FOLLOW-UP
         */

        if (
          nextAction ===
            "follow_up" ||
          nextAction ===
            "followup"
        ) {
          const backendFollowUp =
            extractFollowUpQuestion(
              data,
              parameters
            );

          if (!backendFollowUp) {
            setError(
              "Follow-up question was not received from server."
            );

            setProcessing(false);

            return;
          }

          const current =
            currentQuestionRef.current;

          const followUp =
            normalizeQuestion({
              id:
                parameters?.follow_up_question_id ||
                parameters?.followUpQuestionId ||
                data?.follow_up_question_id ||
                data?.followUpQuestionId ||
                null,

              question:
                backendFollowUp,

              question_number:
                parameters?.question_number ??
                parameters?.questionNumber ??
                current?.question_number ??
                questionNumber,

              question_type:
                parameters?.question_type ||
                parameters?.questionType ||
                "follow_up",

              category:
                parameters?.category ||
                current?.category ||
                "technical",

              difficulty:
                parameters?.difficulty ||
                current?.difficulty ||
                null,

              is_follow_up: true,

              parent_question_id:
                parameters?.parent_question_id ||
                parameters?.parentQuestionId ||
                current?.id ||
                null,
            });

          if (!followUp) {
            setError(
              "Invalid follow-up question received."
            );

            setProcessing(false);

            return;
          }

          currentQuestionRef.current =
            followUp;

          setCurrentQuestion(
            followUp
          );

          setQuestionNumber(
            Number(
              followUp.question_number
            ) || questionNumber
          );

          setAnswer("");

          setLastAnswer("");

          setFollowUpQuestion(null);

          setFollowUpConfirmation(
            false
          );

          setError("");

          setProcessing(false);

          setPhase("question");

          speakQuestion(
            followUp.question
          );

          return;
        }

        /*
         * NEXT MAIN QUESTION
         */

        const nextQuestion =
          extractNextQuestion(
            data,
            parameters
          );

        if (
          nextAction ===
          "next_question"
        ) {
          if (!nextQuestion) {
            setError(
              "Next question was not received from server."
            );

            setProcessing(false);

            return;
          }

          showQuestion(
            nextQuestion
          );

          return;
        }

        /*
         * FALLBACK
         */

        const fallbackText =
          normalizeValue(
            parameters?.text
          ) ||
          normalizeValue(
            data?.text
          ) ||
          normalizeValue(
            data?.fulfillment_text
          ) ||
          normalizeValue(
            data?.fulfillmentText
          );

        if (fallbackText) {
          console.log(
            "Backend message:",
            fallbackText
          );
        }

        setError(
          "Unexpected response received from interview server."
        );

        setProcessing(false);
      },
      [
        completeInterview,
        extractFollowUpQuestion,
        extractNextQuestion,
        questionNumber,
        showQuestion,
        speakQuestion,
      ]
    );

  /*
   * ============================================================
   * START INTERVIEW
   * ============================================================
   */

  /*
   * ============================================================
   * GREETING  ("Are you ready?" -> candidate says / clicks Yes)
   * ============================================================
   * The AI speaks the welcome message, then listens for "yes".
   * The first question is requested only after that.
   */
  useEffect(() => {
    if (phase !== "greeting") {
      return;
    }

    let stopped = false;
    let rec = null;

    const SpeechRecognitionApi =
      window.SpeechRecognition ||
      window.webkitSpeechRecognition;

    const listen = () => {
      if (stopped || !SpeechRecognitionApi) {
        return;
      }

      rec = new SpeechRecognitionApi();
      rec.lang = "en-US";
      rec.continuous = false;
      rec.interimResults = false;

      rec.onresult = (event) => {
        const heard = Array.from(event.results)
          .map((result) => result[0]?.transcript || "")
          .join(" ");

        if (YES_WORDS.test(heard) && !NO_WORDS.test(heard)) {
          stopped = true;
          setReady(true);
        }
      };

      rec.onend = () => {
        if (!stopped) {
          setTimeout(() => {
            try {
              rec.start();
            } catch {}
          }, 300);
        }
      };

      rec.onerror = () => {};

      try {
        rec.start();
      } catch {}
    };

    if (window.speechSynthesis) {
      const utterance = new SpeechSynthesisUtterance(
        GREETING_SPEECH
      );
      utterance.onend = listen;
      utterance.onerror = listen;
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(utterance);
    } else {
      listen();
    }

    return () => {
      stopped = true;
      try {
        rec?.abort();
      } catch {}
      window.speechSynthesis?.cancel();
    };
  }, [phase]);

  /*
   * ============================================================
   * QUESTION TEXT APPEARS WITH THE VOICE
   * ============================================================
   */
  useEffect(() => {
    const text = currentQuestion?.question || "";

    setTypedLength(0);

    if (!text) {
      return;
    }

    const words = text.trim().split(/\s+/).length;

    // speech runs at about 2.4 words / second
    const totalMs = window.speechSynthesis
      ? Math.max(1500, (words / 2.4) * 1000)
      : 800;

    const stepMs = 40;
    const perStep = Math.max(
      1,
      Math.ceil(text.length / (totalMs / stepMs))
    );

    let shown = 0;

    const timer = setInterval(() => {
      shown = Math.min(text.length, shown + perStep);
      setTypedLength(shown);

      if (shown >= text.length) {
        clearInterval(timer);
      }
    }, stepMs);

    return () => clearInterval(timer);
  }, [currentQuestion?.question]);

  /*
   * ============================================================
   * CHAT TRANSCRIPT
   * ============================================================
   */
  useEffect(() => {
    const text = currentQuestion?.question;

    if (!text) {
      return;
    }

    setChatLog((log) => {
      const last = log[log.length - 1];

      if (last && last.role === "ai" && last.text === text) {
        return log;
      }

      return [...log, { role: "ai", text }];
    });
  }, [currentQuestion]);

  useEffect(() => {
    if (!lastAnswer) {
      return;
    }

    setChatLog((log) => [
      ...log,
      { role: "you", text: lastAnswer },
    ]);
  }, [lastAnswer]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatLog]);

  useEffect(() => {
    // wait until the candidate says / clicks "Yes"
    if (!ready) {
      return;
    }

    let cancelled = false;

    async function initializeInterview() {
      try {
        setPhase("loading");
        setError("");

        const response =
          await api.post(
            "/dialogflow/chat",
            {
              session_id:
                sessionId,

              text: "start",

              parameters: {
                session_id:
                  sessionId,

                interview_id:
                  interviewId,

                action: "start",
              },
            }
          );

        if (
          cancelled ||
          !mountedRef.current
        ) {
          return;
        }

        const data =
          response?.data;

        const parameters =
          getMergedParameters(data);

        const rawQuestion =
          parameters?.next_question ||
          parameters?.nextQuestion ||
          data?.next_question ||
          data?.nextQuestion ||
          parameters?.question ||
          data?.question;

        if (rawQuestion) {
          const question =
            normalizeQuestion(
              rawQuestion,
              {
                id:
                  parameters?.question_id ||
                  parameters?.questionId ||
                  data?.question_id ||
                  data?.questionId ||
                  null,

                question_number:
                  parameters?.question_number ??
                  parameters?.questionNumber ??
                  data?.question_number ??
                  data?.questionNumber ??
                  1,

                category:
                  parameters?.category ||
                  data?.category ||
                  "technical",

                difficulty:
                  parameters?.difficulty ||
                  data?.difficulty ||
                  null,

                question_type:
                  parameters?.question_type ||
                  parameters?.questionType ||
                  data?.question_type ||
                  data?.questionType ||
                  "technical",

                is_follow_up:
                  parameters?.is_follow_up ??
                  parameters?.isFollowUp ??
                  data?.is_follow_up ??
                  data?.isFollowUp ??
                  false,

                parent_question_id:
                  parameters?.parent_question_id ||
                  parameters?.parentQuestionId ||
                  data?.parent_question_id ||
                  data?.parentQuestionId ||
                  null,
              }
            );

          if (question) {
            showQuestion(
              question
            );

            return;
          }
        }

        handleDialogflowResponse(
          data
        );
      } catch (err) {
        console.error(
          "Interview initialization error:",
          err
        );

        if (
          !mountedRef.current
        ) {
          return;
        }

        setError(
          err?.response?.data?.detail ||
            err?.message ||
            "Failed to start interview."
        );

        setPhase("error");
      }
    }

    initializeInterview();

    return () => {
      cancelled = true;
    };
  }, [
    ready,
    interviewId,
    sessionId,
    handleDialogflowResponse,
    showQuestion,
  ]);

  /*
   * ============================================================
   * SUBMIT ANSWER
   * ============================================================
   */

  const submitAnswerWithText =
    useCallback(
      async (answerText) => {
        if (
          processingRef.current ||
          completedRef.current ||
          terminatedRef.current
        ) {
          return;
        }

        const cleanAnswer =
          String(
            answerText || ""
          ).trim();

        if (!cleanAnswer) {
          setError(
            "Please provide an answer before submitting."
          );

          return;
        }

        const question =
          currentQuestionRef.current;

        if (!question?.id) {
          setError(
            "Current question is missing."
          );

          return;
        }

        processingRef.current =
          true;

        setProcessing(true);

        setError("");

        setLastAnswer(
          cleanAnswer
        );

        if (
          recognitionRef.current
        ) {
          try {
            recognitionRef.current.stop();
          } catch {}
        }

        window.speechSynthesis?.cancel();

        try {
          const payload = {
            interview_id:
              interviewId,

            session_id:
              sessionId,

            question_id:
              question.id,

            current_question_id:
              question.id,

            candidate_answer:
              cleanAnswer,

            parent_question_id:
              question.parent_question_id ||
              null,

            is_follow_up:
              Boolean(
                question.is_follow_up
              ),

            question_number:
              question.question_number,

            question_type:
              question.question_type ||
              (
                question.is_follow_up
                  ? "follow_up"
                  : "main"
              ),
          };

          console.log(
            "SUBMIT ANSWER PAYLOAD:",
            payload
          );

          const response =
            await api.post(
              "/dialogflow/chat",
              {
                session_id:
                  sessionId,

                text:
                  cleanAnswer,

                parameters:
                  payload,
              }
            );

          if (
            !mountedRef.current ||
            terminatedRef.current
          ) {
            return;
          }

          handleDialogflowResponse(
            response?.data
          );
        } catch (err) {
          console.error(
            "Answer submission error:",
            err
          );

          if (
            !mountedRef.current ||
            terminatedRef.current
          ) {
            return;
          }

          setError(
            err?.response?.data?.detail ||
              err?.message ||
              "Failed to process answer."
          );

          setProcessing(false);
        } finally {
          processingRef.current =
            false;

          if (
            mountedRef.current &&
            !terminatedRef.current
          ) {
            setProcessing(false);
          }
        }
      },
      [
        interviewId,
        sessionId,
        handleDialogflowResponse,
      ]
    );

  submitAnswerRef.current =
    submitAnswerWithText;

  phaseRef.current = phase;

  /*
   * ============================================================
   * FOLLOW-UP YES
   * ============================================================
   */

  const handleFollowUpYes =
    async () => {
      if (
        processingRef.current ||
        completedRef.current ||
        terminatedRef.current
      ) {
        return;
      }

      const question =
        currentQuestionRef.current;

      if (!question?.id) {
        setError(
          "Current question is missing."
        );

        return;
      }

      processingRef.current =
        true;

      setProcessing(true);

      setError("");

      try {
        const response =
          await api.post(
            "/dialogflow/chat",
            {
              session_id:
                sessionId,

              text: "yes",

              parameters: {
                session_id:
                  sessionId,

                interview_id:
                  interviewId,

                question_id:
                  question.id,

                current_question_id:
                  question.id,

                candidate_answer:
                  "yes",

                follow_up_confirmation:
                  "yes",
                // FIX: tells the backend this is a YES/NO answer to the
                // follow-up offer, not an answer to the interview question.
                follow_up_confirmation_required:
                  true,

                is_follow_up:
                  false,

                question_number:
                  question.question_number,
              },
            }
          );

        if (
          !mountedRef.current ||
          terminatedRef.current
        ) {
          return;
        }

        handleDialogflowResponse(
          response?.data
        );
      } catch (err) {
        if (
          mountedRef.current
        ) {
          setError(
            err?.response?.data?.detail ||
              err?.message ||
              "Unable to generate follow-up question."
          );
        }
      } finally {
        processingRef.current =
          false;

        if (
          mountedRef.current &&
          !terminatedRef.current
        ) {
          setProcessing(false);
        }
      }
    };

  /*
   * ============================================================
   * FOLLOW-UP NO
   * ============================================================
   */

  const handleFollowUpNo =
    async () => {
      if (
        processingRef.current ||
        completedRef.current ||
        terminatedRef.current
      ) {
        return;
      }

      const question =
        currentQuestionRef.current;

      if (!question?.id) {
        setError(
          "Current question is missing."
        );

        return;
      }

      processingRef.current =
        true;

      setProcessing(true);

      setError("");

      try {
        const response =
          await api.post(
            "/dialogflow/chat",
            {
              session_id:
                sessionId,

              text: "no",

              parameters: {
                session_id:
                  sessionId,

                interview_id:
                  interviewId,

                question_id:
                  question.id,

                current_question_id:
                  question.id,

                candidate_answer:
                  "no",

                follow_up_confirmation:
                  "no",
                // FIX: tells the backend this is a YES/NO answer to the
                // follow-up offer, not an answer to the interview question.
                follow_up_confirmation_required:
                  true,

                is_follow_up:
                  false,

                question_number:
                  question.question_number,
              },
            }
          );

        if (
          !mountedRef.current ||
          terminatedRef.current
        ) {
          return;
        }

        handleDialogflowResponse(
          response?.data
        );
      } catch (err) {
        if (
          mountedRef.current
        ) {
          setError(
            err?.response?.data?.detail ||
              err?.message ||
              "Unable to move to next question."
          );
        }
      } finally {
        processingRef.current =
          false;

        if (
          mountedRef.current &&
          !terminatedRef.current
        ) {
          setProcessing(false);
        }
      }
    };

  followUpYesRef.current =
    handleFollowUpYes;

  followUpNoRef.current =
    handleFollowUpNo;

  /*
   * ============================================================
   * VOICE RECOGNITION
   * ============================================================
   */

  useEffect(() => {
    const SpeechRecognition =
      window.SpeechRecognition ||
      window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setVoiceSupported(false);
      return;
    }

    setVoiceSupported(true);

    const recognition =
      new SpeechRecognition();

    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = "en-US";

    recognition.onstart = () => {
      if (
        mountedRef.current
      ) {
        setIsListening(true);
      }
    };

    recognition.onresult = (
      event
    ) => {
      let transcript = "";

      for (
        let i =
          event.resultIndex;
        i <
        event.results.length;
        i++
      ) {
        transcript +=
          event.results[i][0]
            .transcript;
      }

      transcript =
        transcript.trim();

      /*
       * FOLLOW-UP OFFER: the candidate is answering YES / NO,
       * not answering an interview question.
       */
      if (
        phaseRef.current ===
        "followup-confirmation"
      ) {
        const lastChunk =
          event.results[
            event.results.length - 1
          ];

        if (
          lastChunk?.isFinal &&
          mountedRef.current &&
          !processingRef.current
        ) {
          const decision =
            parseYesNo(transcript);

          if (decision === "yes") {
            followUpYesRef.current?.();
          } else if (
            decision === "no"
          ) {
            followUpNoRef.current?.();
          } else {
            speakThenRef.current?.(
              "Sorry, I did not catch that. Please say yes or no.",
              () =>
                startListeningRef.current?.()
            );
          }
        }

        return;
      }

      if (
        transcript &&
        mountedRef.current
      ) {
        setAnswer(transcript);
      }

      const lastResult =
        event.results[
          event.results.length - 1
        ];

      if (
        lastResult?.isFinal &&
        autoSubmitVoice &&
        transcript
      ) {
        setTimeout(() => {
          if (
            mountedRef.current &&
            !processingRef.current &&
            !completedRef.current &&
            !terminatedRef.current
          ) {
            submitAnswerRef.current?.(
              transcript
            );
          }
        }, 300);
      }
    };

    recognition.onerror = (
      event
    ) => {
      console.error(
        "Speech recognition error:",
        event
      );

      if (
        mountedRef.current
      ) {
        setIsListening(false);
      }
    };

    recognition.onend = () => {
      if (
        mountedRef.current
      ) {
        setIsListening(false);
      }

      // Candidate stayed silent during the follow-up offer:
      // listen again a few times.
      if (
        mountedRef.current &&
        phaseRef.current ===
          "followup-confirmation" &&
        !processingRef.current &&
        !terminatedRef.current &&
        !window.speechSynthesis?.speaking &&
        confirmRetryRef.current < 4
      ) {
        confirmRetryRef.current += 1;

        setTimeout(() => {
          if (
            mountedRef.current &&
            phaseRef.current ===
              "followup-confirmation" &&
            !processingRef.current
          ) {
            startListeningRef.current?.();
          }
        }, 600);
      }
    };

    recognitionRef.current =
      recognition;

    return () => {
      try {
        recognition.stop();
      } catch {}

      recognitionRef.current =
        null;
    };
  }, [autoSubmitVoice]);

  /*
   * ============================================================
   * START LISTENING
   * ============================================================
   */

  const startListening =
    () => {
      if (
        !recognitionRef.current ||
        processingRef.current ||
        completedRef.current ||
        terminatedRef.current
      ) {
        return;
      }

      try {
        recognitionRef.current.start();
      } catch {
        console.warn(
          "Speech recognition already running."
        );
      }
    };

  /*
   * ============================================================
   * STOP LISTENING
   * ============================================================
   */

  const stopListening =
    () => {
      if (
        !recognitionRef.current
      ) {
        return;
      }

      try {
        recognitionRef.current.stop();
      } catch {}
    };

  startListeningRef.current =
    startListening;

  /*
   * ============================================================
   * SPEAK + CALLBACK (voice follow-up offer)
   * ============================================================
   */
  const speakThen =
    (text, onDone) => {
      if (
        !window.speechSynthesis
      ) {
        onDone?.();
        return;
      }

      speechGenerationRef.current += 1;
      const generation =
        speechGenerationRef.current;

      try {
        recognitionRef.current?.stop();
      } catch {}

      window.speechSynthesis.cancel();

      const utterance =
        new SpeechSynthesisUtterance(
          text
        );

      utterance.rate = 0.95;

      utterance.onstart = () => {
        if (mountedRef.current) {
          setIsSpeaking(true);
        }
      };

      const finish = () => {
        if (!mountedRef.current) {
          return;
        }

        setIsSpeaking(false);

        if (
          generation ===
          speechGenerationRef.current
        ) {
          onDone?.();
        }
      };

      utterance.onend = finish;
      utterance.onerror = finish;

      window.speechSynthesis.speak(
        utterance
      );
    };

  speakThenRef.current =
    speakThen;

  /*
   * ============================================================
   * FOLLOW-UP OFFER BY VOICE
   * ============================================================
   * When the backend offers a follow-up, the AI asks out loud,
   * then the microphone starts by itself so the candidate can
   * just say "yes" or "no". Buttons still work.
   */
  useEffect(() => {
    if (
      phase !== "followup-confirmation"
    ) {
      return undefined;
    }

    confirmRetryRef.current = 0;

    let cancelled = false;

    const timer = setTimeout(() => {
      speakThenRef.current?.(
        "Would you like a follow-up question? Please say yes or no.",
        () => {
          if (
            !cancelled &&
            phaseRef.current ===
              "followup-confirmation"
          ) {
            startListeningRef.current?.();
          }
        }
      );
    }, 500);

    return () => {
      cancelled = true;
      clearTimeout(timer);

      try {
        recognitionRef.current?.stop();
      } catch {}
    };
  }, [phase]);

  /*
   * ============================================================
   * CAMERA START
   * ============================================================
   *
   * IMPORTANT FIX:
   *
   * Do NOT attach stream to videoRef here.
   *
   * The <video> element exists only after
   * cameraEnabled becomes true.
   *
   * A separate effect below attaches
   * stream -> video.
   * ============================================================
   */

  const startCamera =
    useCallback(
      async () => {
        if (
          completedRef.current ||
          terminatedRef.current
        ) {
          return false;
        }

        if (
          !navigator.mediaDevices ||
          !navigator.mediaDevices
            .getUserMedia
        ) {
          setError(
            "Camera is not supported by this browser."
          );

          return false;
        }

        /*
         * Already running
         */
        if (streamRef.current) {
          setCameraEnabled(true);

          return true;
        }

        try {
          console.log(
            "Starting camera..."
          );

          const stream =
            await navigator.mediaDevices.getUserMedia(
              {
                video: {
                  facingMode:
                    "user",

                  width: {
                    ideal: 640,
                  },

                  height: {
                    ideal: 480,
                  },

                  frameRate: {
                    ideal: 30,
                    max: 30,
                  },
                },

                audio: false,
              }
            );

          if (
            !mountedRef.current ||
            completedRef.current ||
            terminatedRef.current
          ) {
            stream
              .getTracks()
              .forEach(
                (track) => {
                  try {
                    track.stop();
                  } catch {}
                }
              );

            return false;
          }

          streamRef.current =
            stream;

          console.log(
            "Camera stream started:",
            stream
          );

          /*
           * IMPORTANT:
           *
           * Video element will be attached
           * by the useEffect below.
           */
          setCameraEnabled(true);

          return true;
        } catch (err) {
          console.error(
            "Camera error:",
            err
          );

          setError(
            err?.name ===
              "NotAllowedError"
              ? "Camera permission was denied. Please allow camera access in the browser."
              : err?.name ===
                "NotFoundError"
              ? "No camera was found on this device."
              : "Camera access could not be started."
          );

          setCameraEnabled(false);

          return false;
        }
      },
      []
    );

  /*
   * ============================================================
   * IMPORTANT CAMERA -> VIDEO ATTACHMENT
   * ============================================================
   *
   * THIS FIXES THE MAIN PROBLEM.
   *
   * React first renders <video> after
   * cameraEnabled becomes true.
   *
   * Then this effect gets the real videoRef
   * and attaches the already-running camera stream.
   */

  useEffect(() => {
    if (!cameraEnabled) {
      return;
    }

    const video =
      videoRef.current;

    const stream =
      streamRef.current;

    if (!video) {
      console.warn(
        "Video element not ready yet."
      );

      return;
    }

    if (!stream) {
      console.warn(
        "Camera stream not available."
      );

      return;
    }

    console.log(
      "Attaching camera stream to video element..."
    );

    if (
      video.srcObject !== stream
    ) {
      video.srcObject = stream;
    }

    const playVideo =
      async () => {
        try {
          await video.play();

          console.log(
            "Camera video playback started."
          );
        } catch (err) {
          console.warn(
            "Video playback failed:",
            err
          );
        }
      };

    /*
     * Sometimes metadata needs to load
     * before play().
     */
    if (
      video.readyState >=
      HTMLMediaElement.HAVE_METADATA
    ) {
      playVideo();
    } else {
      const handleLoadedMetadata =
        () => {
          playVideo();
        };

      video.addEventListener(
        "loadedmetadata",
        handleLoadedMetadata,
        {
          once: true,
        }
      );

      return () => {
        video.removeEventListener(
          "loadedmetadata",
          handleLoadedMetadata
        );
      };
    }
  }, [cameraEnabled, phase]);

  /*
   * ============================================================
   * CAMERA OFF
   * ============================================================
   */

  const disableCamera =
    useCallback(() => {
      console.log(
        "Disabling camera..."
      );

      if (streamRef.current) {
        streamRef.current
          .getTracks()
          .forEach((track) => {
            try {
              track.stop();
            } catch {}
          });

        streamRef.current =
          null;
      }

      if (videoRef.current) {
        try {
          videoRef.current.pause();
        } catch {}

        videoRef.current.srcObject =
          null;
      }

      /*
       * Camera OFF automatically
       * disables Face + Eye/Gaze.
       */

      setCameraEnabled(false);

      setFaceDetectionEnabled(
        false
      );

      setEyeGazeEnabled(false);

      setFaceStatus(
        "Face detection OFF"
      );

      setEyeStatus(
        "Eye/Gaze detection OFF"
      );

      /*
       * Stop monitoring loop
       */

      monitoringRunningRef.current =
        false;

      if (
        monitoringFrameRef.current
      ) {
        cancelAnimationFrame(
          monitoringFrameRef.current
        );

        monitoringFrameRef.current =
          null;
      }

      noFaceSinceRef.current =
        null;

      multipleFaceSinceRef.current =
        null;

      eyesClosedSinceRef.current =
        null;

      lookingAwaySinceRef.current =
        null;
    }, []);

  /*
   * ============================================================
   * CAMERA TOGGLE
   * ============================================================
   */

  const toggleCamera =
    async () => {
      if (cameraEnabled) {
        disableCamera();
        return;
      }

      await startCamera();
    };

  /*
   * ============================================================
   * FACE DETECTION ON
   * ============================================================
   */

  const enableFaceDetection =
    useCallback(
      async () => {
        /*
         * Camera required
         */
        if (!cameraEnabled) {
          const started =
            await startCamera();

          if (!started) {
            return;
          }
        }

        /*
         * MediaPipe will initialize
         * through the effect below.
         */

        setFaceDetectionEnabled(
          true
        );

        setFaceStatus(
          "Starting face detection..."
        );
      },
      [
        cameraEnabled,
        startCamera,
      ]
    );

  /*
   * ============================================================
   * FACE DETECTION OFF
   * ============================================================
   */

  const disableFaceDetection =
    useCallback(() => {
      setFaceDetectionEnabled(
        false
      );

      /*
       * Eye/Gaze requires face.
       */

      setEyeGazeEnabled(false);

      setFaceStatus(
        "Face detection OFF"
      );

      setEyeStatus(
        "Eye/Gaze detection OFF"
      );

      noFaceSinceRef.current =
        null;

      multipleFaceSinceRef.current =
        null;

      eyesClosedSinceRef.current =
        null;

      lookingAwaySinceRef.current =
        null;
    }, []);

  /*
   * ============================================================
   * FACE TOGGLE
   * ============================================================
   */

  const toggleFaceDetection =
    async () => {
      if (
        faceDetectionEnabled
      ) {
        disableFaceDetection();

        return;
      }

      await enableFaceDetection();
    };

  /*
   * ============================================================
   * EYE / GAZE ON
   * ============================================================
   */

  const enableEyeGaze =
    useCallback(
      async () => {
        /*
         * Camera required
         */

        if (!cameraEnabled) {
          const started =
            await startCamera();

          if (!started) {
            return;
          }
        }

        /*
         * Face required
         */

        if (!faceDetectionEnabled) {
          setFaceDetectionEnabled(
            true
          );

          setFaceStatus(
            "Starting face detection..."
          );
        }

        setEyeGazeEnabled(true);

        setEyeStatus(
          "Starting eye/gaze detection..."
        );
      },
      [
        cameraEnabled,
        faceDetectionEnabled,
        startCamera,
      ]
    );

  /*
   * ============================================================
   * EYE / GAZE OFF
   * ============================================================
   */

  const disableEyeGaze =
    useCallback(() => {
      setEyeGazeEnabled(false);

      setEyeStatus(
        "Eye/Gaze detection OFF"
      );

      eyesClosedSinceRef.current =
        null;

      lookingAwaySinceRef.current =
        null;
    }, []);

  /*
   * ============================================================
   * EYE / GAZE TOGGLE
   * ============================================================
   */

  const toggleEyeGaze =
    async () => {
      if (eyeGazeEnabled) {
        disableEyeGaze();

        return;
      }

      await enableEyeGaze();
    };

  /*
   * ============================================================
   * MONITORING POLICY (set by the interviewer)
   * ============================================================
   */

  useEffect(() => {
    let cancelled = false;

    async function loadPolicy() {
      try {
        // A temporary network/server error must not silently
        // switch OFF monitoring the interviewer turned ON, so
        // retry a few times. 401/403/404 are final answers
        // (404 = interviewer never enabled anything).
        const fetchPolicy = async () => {
          let lastError;

          for (
            let attempt = 0;
            attempt < 3;
            attempt += 1
          ) {
            try {
              return await api.get(
                `/interviews/${interviewId}/configuration`
              );
            } catch (err) {
              lastError = err;

              const code =
                err?.response?.status;

              if (
                code === 401 ||
                code === 403 ||
                code === 404
              ) {
                throw err;
              }

              await new Promise(
                (resolve) =>
                  setTimeout(
                    resolve,
                    700 * (attempt + 1)
                  )
              );

              if (cancelled) {
                throw err;
              }
            }
          }

          throw lastError;
        };

        const response =
          await fetchPolicy();

        if (cancelled) {
          return;
        }

        const raw =
          response.data
            ?.extra_config
            ?.proctoring || {};

        const enabled =
          Boolean(raw.enabled);

        const face =
          enabled &&
          Boolean(raw.face);

        const eye =
          face &&
          Boolean(raw.eye);

        const phone =
          enabled &&
          Boolean(raw.phone);

        setPolicy({
          loaded: true,
          enabled,
          face,
          eye,
          phone,
        });
      } catch (err) {
        console.warn(
          "Monitoring policy could not be loaded. " +
            "Continuing without monitoring.",
          err
        );

        if (!cancelled) {
          setPolicy({
            loaded: true,
            enabled: false,
            face: false,
            eye: false,
            phone: false,
          });
        }
      }
    }

    loadPolicy();

    return () => {
      cancelled = true;
    };
  }, [interviewId]);

  const startMonitoring =
    useCallback(
      async () => {
        if (
          completedRef.current ||
          terminatedRef.current
        ) {
          return;
        }

        setCameraBlocked(false);

        const started =
          await startCamera();

        if (!started) {
          setCameraBlocked(true);

          api
            .post(
              `/hiring/sessions/${sessionId}/monitoring-event`,
              {
                type:
                  "camera_denied",
              }
            )
            .catch(() => {});

          return;
        }

        if (policy.face) {
          setFaceDetectionEnabled(
            true
          );

          setFaceStatus(
            "Starting face detection..."
          );
        }

        if (policy.eye) {
          setEyeGazeEnabled(true);

          setEyeStatus(
            "Starting eye/gaze detection..."
          );
        }
      },
      [
        policy,
        sessionId,
        startCamera,
      ]
    );

  useEffect(() => {
    if (
      !policy.loaded ||
      !policy.enabled ||
      autoStartedRef.current
    ) {
      return;
    }

    autoStartedRef.current = true;

    startMonitoring();
  }, [policy, startMonitoring]);

  /*
   * ============================================================
   * MEDIAPIPE INITIALIZATION
   * ============================================================
   */

  useEffect(() => {
    const needsFaceModel =
      faceDetectionEnabled ||
      eyeGazeEnabled;

    if (!needsFaceModel) {
      setMonitoringReady(false);

      /*
       * Stop existing loop
       */

      monitoringRunningRef.current =
        false;

      if (
        monitoringFrameRef.current
      ) {
        cancelAnimationFrame(
          monitoringFrameRef.current
        );

        monitoringFrameRef.current =
          null;
      }

      /*
       * Close existing model
       */

      if (
        faceLandmarkerRef.current
      ) {
        try {
          faceLandmarkerRef.current.close();
        } catch {}

        faceLandmarkerRef.current =
          null;
      }

      return;
    }

    let cancelled = false;

    async function initializeFaceMonitoring() {
      /*
       * Reuse model
       */

      if (
        faceLandmarkerRef.current
      ) {
        if (!cancelled) {
          setMonitoringReady(
            true
          );
        }

        return;
      }

      try {
        setFaceStatus(
          "Loading face detection..."
        );

        console.log(
          "Loading MediaPipe..."
        );

        // Loaded only now (and only when the interviewer turned
        // monitoring on) - it is a big library.
        const { FaceLandmarker, FilesetResolver } = await import(
          "@mediapipe/tasks-vision"
        );

        const vision =
          await FilesetResolver.forVisionTasks(
            MEDIAPIPE_WASM_URL
          );

        if (cancelled) {
          return;
        }

        console.log(
          "MediaPipe WASM loaded."
        );

        const faceLandmarker =
          await FaceLandmarker.createFromOptions(
            vision,
            {
              baseOptions: {
                modelAssetPath:
                  "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/latest/face_landmarker.task",

                /*
                 * GPU can fail on some systems.
                 * CPU is more compatible.
                 */
                delegate: "CPU",
              },

              runningMode: "VIDEO",

              numFaces: 2,

              minFaceDetectionConfidence:
                0.5,

              minFacePresenceConfidence:
                0.5,

              minTrackingConfidence:
                0.5,

              // needed for the "looking down" check
              outputFaceBlendshapes:
                true,

              outputFacialTransformationMatrixes:
                false,
            }
          );

        if (
          cancelled ||
          !mountedRef.current
        ) {
          try {
            faceLandmarker.close();
          } catch {}

          return;
        }

        faceLandmarkerRef.current =
          faceLandmarker;

        setMonitoringReady(true);

        logMonitoringEventRef.current?.(
          "monitoring_started"
        );

        setFaceStatus(
          "Face detection ready"
        );

        console.log(
          "MediaPipe FaceLandmarker ready."
        );

        /*
         * Camera should already exist,
         * but make sure it exists.
         */

        if (!streamRef.current) {
          await startCamera();
        }
      } catch (err) {
        console.error(
          "MediaPipe initialization failed:",
          err
        );

        if (
          cancelled ||
          !mountedRef.current
        ) {
          return;
        }

        setMonitoringReady(false);

        setFaceDetectionEnabled(
          false
        );

        setEyeGazeEnabled(false);

        setFaceStatus(
          "Face detection unavailable"
        );

        setEyeStatus(
          "Eye/Gaze detection OFF"
        );

        setError(
          "Face detection could not be started. Please check your camera and browser."
        );
      }
    }

    initializeFaceMonitoring();

    return () => {
      cancelled = true;
    };
  }, [
    faceDetectionEnabled,
    eyeGazeEnabled,
    startCamera,
  ]);

  /*
   * ============================================================
   * FACE / EYE PROCESSING LOOP
   * ============================================================
   */

  useEffect(() => {
    /*
     * Required conditions
     */

    if (
      !faceDetectionEnabled ||
      !monitoringReady ||
      !faceLandmarkerRef.current ||
      !cameraEnabled
    ) {
      monitoringRunningRef.current =
        false;

      if (
        monitoringFrameRef.current
      ) {
        cancelAnimationFrame(
          monitoringFrameRef.current
        );

        monitoringFrameRef.current =
          null;
      }

      return;
    }

    let cancelled = false;

    const monitor =
      () => {
        if (
          cancelled ||
          !mountedRef.current ||
          completedRef.current ||
          terminatedRef.current ||
          !faceDetectionEnabled ||
          !cameraEnabled
        ) {
          return;
        }

        const video =
          videoRef.current;

        const landmarker =
          faceLandmarkerRef.current;

        /*
         * Video must have actual data
         */

        if (
          !video ||
          !landmarker ||
          video.readyState <
            HTMLMediaElement.HAVE_CURRENT_DATA
        ) {
          monitoringFrameRef.current =
            requestAnimationFrame(
              monitor
            );

          return;
        }

        /*
         * Make sure video is actually playing
         */

        if (video.paused) {
          video.play().catch(
            () => {}
          );
        }

        try {
          const now =
            performance.now();

          const result =
            landmarker.detectForVideo(
              video,
              now
            );

          const faces =
            result?.faceLandmarks ||
            [];

          /*
           * ==================================================
           * FACE DETECTION
           * ==================================================
           */

          if (faces.length === 0) {
            setFaceStatus(
              "No face detected"
            );

            if (
              eyeGazeEnabled
            ) {
              setEyeStatus(
                "Eyes unavailable"
              );
            }

            if (
              !noFaceSinceRef.current
            ) {
              noFaceSinceRef.current =
                Date.now();

              logMonitoringEventRef.current?.(
                "face_not_found"
              );
            }

            /*
             * Give detection some time
             * before terminating.
             */
            const duration =
              Date.now() -
              noFaceSinceRef.current;

            if (
              duration >= 3000 &&
              faceDetectionEnabled
            ) {
              terminateInterviewRef.current?.(
                "no_face_detected"
              );

              return;
            }
          } else {
            noFaceSinceRef.current =
              null;
          }

          /*
           * ==================================================
           * MULTIPLE FACE
           * ==================================================
           */

          if (faces.length > 1) {
            setFaceStatus(
              "Multiple faces detected"
            );

            if (
              !multipleFaceSinceRef.current
            ) {
              multipleFaceSinceRef.current =
                Date.now();

              logMonitoringEventRef.current?.(
                "multiple_faces"
              );
            }

            const duration =
              Date.now() -
              multipleFaceSinceRef.current;

            if (
              duration >= 2000 &&
              faceDetectionEnabled
            ) {
              terminateInterviewRef.current?.(
                "multiple_faces_detected"
              );

              return;
            }
          } else {
            multipleFaceSinceRef.current =
              null;

            if (
              faces.length === 1
            ) {
              setFaceStatus(
                "Face detected"
              );
            }
          }

          /*
           * ==================================================
           * EYE / GAZE DETECTION
           * ==================================================
           */

          if (
            eyeGazeEnabled &&
            faces.length === 1
          ) {
            const landmarks =
              faces[0];

            /*
             * LEFT EYE
             */

            const leftEAR =
              calculateEyeAspectRatio(
                landmarks[159],
                landmarks[145],
                landmarks[33],
                landmarks[133]
              );

            /*
             * RIGHT EYE
             */

            const rightEAR =
              calculateEyeAspectRatio(
                landmarks[386],
                landmarks[374],
                landmarks[362],
                landmarks[263]
              );

            const averageEAR =
              (leftEAR +
                rightEAR) /
              2;

            /*
             * EYE CLOSED
             */

            const eyesClosed =
              averageEAR < 0.16;

            if (eyesClosed) {
              setEyeStatus(
                "Eyes closed"
              );

              if (
                !eyesClosedSinceRef.current
              ) {
                eyesClosedSinceRef.current =
                  Date.now();

              logMonitoringEventRef.current?.(
                "eyes_closed"
              );
              }

              const duration =
                Date.now() -
                eyesClosedSinceRef.current;

              if (
                duration >= 1800 &&
                eyeGazeEnabled
              ) {
                terminateInterviewRef.current?.(
                  "eyes_closed"
                );

                return;
              }
            } else {
              eyesClosedSinceRef.current =
                null;

              setEyeStatus(
                "Eyes open"
              );
            }

            /*
             * IRIS
             */

            const leftIris =
              landmarks.slice(
                468,
                473
              );

            const rightIris =
              landmarks.slice(
                473,
                478
              );

            const leftGaze =
              calculateIrisPosition(
                leftIris,
                landmarks[33],
                landmarks[133]
              );

            const rightGaze =
              calculateIrisPosition(
                rightIris,
                landmarks[362],
                landmarks[263]
              );

            const averageGaze =
              (leftGaze +
                rightGaze) /
              2;

            /*
             * Looking away threshold
             */

            const lookingAway =
              averageGaze < 0.20 ||
              averageGaze > 0.80;

            if (lookingAway) {
              setEyeStatus(
                "Looking away"
              );

              if (
                !lookingAwaySinceRef.current
              ) {
                lookingAwaySinceRef.current =
                  Date.now();

              logMonitoringEventRef.current?.(
                "looking_away"
              );
              }

              const duration =
                Date.now() -
                lookingAwaySinceRef.current;

              if (
                duration >= 1800 &&
                eyeGazeEnabled
              ) {
                terminateInterviewRef.current?.(
                  "looking_away"
                );

                return;
              }
            } else {
              lookingAwaySinceRef.current =
                null;

              if (!eyesClosed) {
                setEyeStatus(
                  "Eyes focused"
                );
              }
            }
          }

          /*
           * ==================================================
           * LOOKING DOWN (phone / notes below the camera)
           * One long look down, or several short glances
           * ==================================================
           */

          if (
            eyeGazeEnabled &&
            faces.length === 1
          ) {
            const shapes =
              result
                ?.faceBlendshapes?.[0]
                ?.categories || [];

            const shapeScore =
              (name) =>
                shapes.find(
                  (s) =>
                    s.categoryName ===
                    name
                )?.score || 0;

            const downScore =
              (shapeScore(
                "eyeLookDownLeft"
              ) +
                shapeScore(
                  "eyeLookDownRight"
                )) /
              2;

            const blinkScore =
              (shapeScore(
                "eyeBlinkLeft"
              ) +
                shapeScore(
                  "eyeBlinkRight"
                )) /
              2;

            // blinking also raises the "down" score, so ignore it
            const lookingDown =
              shapes.length > 0 &&
              downScore >=
                LOOK_DOWN_SCORE &&
              blinkScore < 0.6;

            if (lookingDown) {
              setEyeStatus(
                "Looking down"
              );

              const nowMs =
                Date.now();

              if (
                !lookDownSinceRef.current
              ) {
                lookDownSinceRef.current =
                  nowMs;
              }

              const downFor =
                nowMs -
                lookDownSinceRef.current;

              if (
                downFor >=
                  LOOK_DOWN_EPISODE_MS &&
                !lookDownCountedRef.current
              ) {
                lookDownCountedRef.current =
                  true;

                logMonitoringEventRef.current?.(
                  "looking_down"
                );

                const recent =
                  downEpisodesRef.current.filter(
                    (at) =>
                      nowMs - at <
                      LOOK_DOWN_REPEAT_WINDOW_MS
                  );

                recent.push(nowMs);

                downEpisodesRef.current =
                  recent;

                if (
                  recent.length >=
                  LOOK_DOWN_REPEAT_COUNT
                ) {
                  terminateInterviewRef.current?.(
                    "repeated_looking_down"
                  );

                  return;
                }
              }

              if (
                downFor >=
                LOOK_DOWN_TERMINATE_MS
              ) {
                terminateInterviewRef.current?.(
                  "looking_down"
                );

                return;
              }
            } else {
              lookDownSinceRef.current =
                null;

              lookDownCountedRef.current =
                false;
            }
          } else {
            lookDownSinceRef.current =
              null;

            lookDownCountedRef.current =
              false;
          }

          /*
           * Eye OFF
           */

          if (!eyeGazeEnabled) {
            eyesClosedSinceRef.current =
              null;

            lookingAwaySinceRef.current =
              null;

            setEyeStatus(
              "Eye/Gaze detection OFF"
            );
          }
        } catch (err) {
          console.error(
            "Face monitoring frame error:",
            err
          );
        }

        monitoringFrameRef.current =
          requestAnimationFrame(
            monitor
          );
      };

    monitoringRunningRef.current =
      true;

    monitoringFrameRef.current =
      requestAnimationFrame(
        monitor
      );

    return () => {
      cancelled = true;

      if (
        monitoringFrameRef.current
      ) {
        cancelAnimationFrame(
          monitoringFrameRef.current
        );

        monitoringFrameRef.current =
          null;
      }

      monitoringRunningRef.current =
        false;

      noFaceSinceRef.current =
        null;

      multipleFaceSinceRef.current =
        null;

      eyesClosedSinceRef.current =
        null;

      lookingAwaySinceRef.current =
        null;

      lookDownSinceRef.current =
        null;

      lookDownCountedRef.current =
        false;
    };
  }, [
    cameraEnabled,
    faceDetectionEnabled,
    eyeGazeEnabled,
    monitoringReady,
  ]);

  /*
   * ============================================================
   * PHONE DETECTION
   * ============================================================
   *
   * Runs only when the interviewer turned "Phone detection" on.
   * Independent of face detection: it only needs the camera.
   * The model is loaded lazily, so interviews without phone
   * detection never download it.
   */

  useEffect(() => {
    if (!policy.phone) {
      setPhoneStatus(
        "Phone detection OFF"
      );

      return;
    }

    if (!cameraEnabled) {
      setPhoneStatus(
        "Waiting for camera..."
      );

      return;
    }

    let cancelled = false;
    let timer = null;
    let detector = null;

    const check = () => {
      if (
        cancelled ||
        !mountedRef.current ||
        completedRef.current ||
        terminatedRef.current
      ) {
        return;
      }

      const video =
        videoRef.current;

      if (
        !detector ||
        !video ||
        video.readyState <
          HTMLMediaElement.HAVE_CURRENT_DATA
      ) {
        return;
      }

      try {
        const result =
          detector.detectForVideo(
            video,
            performance.now()
          );

        const found = (
          result?.detections || []
        ).some((d) =>
          (d.categories || []).some(
            (cat) =>
              cat.categoryName ===
                "cell phone" &&
              cat.score >=
                PHONE_SCORE_THRESHOLD
          )
        );

        const nowMs = Date.now();

        if (found) {
          phoneLastSeenRef.current =
            nowMs;

          if (
            !phoneSinceRef.current
          ) {
            phoneSinceRef.current =
              nowMs;

            logMonitoringEventRef.current?.(
              "phone_detected"
            );
          }

          setPhoneStatus(
            "Phone detected"
          );

          if (
            nowMs -
              phoneSinceRef.current >=
            PHONE_TERMINATE_MS
          ) {
            terminateInterviewRef.current?.(
              "phone_detected"
            );
          }
        } else if (
          phoneSinceRef.current &&
          nowMs -
            phoneLastSeenRef.current >
            PHONE_GRACE_MS
        ) {
          phoneSinceRef.current =
            null;

          setPhoneStatus(
            "No phone detected"
          );
        } else if (
          !phoneSinceRef.current
        ) {
          setPhoneStatus(
            "No phone detected"
          );
        }
      } catch (err) {
        console.error(
          "Phone detection frame error:",
          err
        );
      }
    };

    async function startPhoneDetection() {
      try {
        setPhoneStatus(
          "Loading phone detection..."
        );

        const {
          ObjectDetector,
          FilesetResolver,
        } = await import(
          "@mediapipe/tasks-vision"
        );

        const vision =
          await FilesetResolver.forVisionTasks(
            MEDIAPIPE_WASM_URL
          );

        if (cancelled) {
          return;
        }

        detector =
          await ObjectDetector.createFromOptions(
            vision,
            {
              baseOptions: {
                modelAssetPath:
                  PHONE_MODEL_URL,

                delegate: "CPU",
              },

              runningMode: "VIDEO",

              scoreThreshold:
                PHONE_SCORE_THRESHOLD,

              maxResults: 5,

              categoryAllowlist: [
                "cell phone",
              ],
            }
          );

        if (
          cancelled ||
          !mountedRef.current
        ) {
          try {
            detector.close();
          } catch {}

          detector = null;

          return;
        }

        objectDetectorRef.current =
          detector;

        setPhoneStatus(
          "No phone detected"
        );

        timer = setInterval(
          check,
          PHONE_CHECK_INTERVAL_MS
        );
      } catch (err) {
        console.error(
          "Phone detection could not start:",
          err
        );

        if (!cancelled) {
          setPhoneStatus(
            "Phone detection unavailable"
          );
        }
      }
    }

    startPhoneDetection();

    return () => {
      cancelled = true;

      if (timer) {
        clearInterval(timer);
      }

      if (detector) {
        try {
          detector.close();
        } catch {}
      }

      detector = null;

      objectDetectorRef.current =
        null;

      phoneSinceRef.current =
        null;

      phoneLastSeenRef.current =
        0;
    };
  }, [
    policy.phone,
    cameraEnabled,
  ]);

  /*
   * ============================================================
   * FORMAT TIME
   * ============================================================
   */

  const formatTime =
    (seconds) => {
      const minutes =
        Math.floor(
          seconds / 60
        );

      const secs =
        seconds % 60;

      return `${String(
        minutes
      ).padStart(
        2,
        "0"
      )}:${String(
        secs
      ).padStart(
        2,
        "0"
      )}`;
    };

  /*
   * ============================================================
   * LOADING
   * ============================================================
   */

  if (phase === "greeting") {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-6 relative overflow-hidden font-sans">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-indigo-500/20 rounded-full blur-[120px] pointer-events-none" />

        <div className="max-w-lg w-full bg-slate-900/80 border border-slate-800 backdrop-blur-2xl p-8 rounded-3xl text-center space-y-5 shadow-2xl relative z-10">
          <div className="w-16 h-16 bg-indigo-500/10 border border-indigo-500/30 rounded-2xl flex items-center justify-center text-3xl mx-auto">
            🤖
          </div>

          <h1 className="text-2xl font-bold text-white">
            Hello! Welcome to the AI Interview.
          </h1>

          <p className="text-slate-300 text-sm leading-relaxed">
            I'll guide you through the interview and ask you a series of
            questions based on your interview configuration.
          </p>

          <p className="text-slate-100 font-semibold">
            Are you ready to start your interview?
          </p>

          <button
            type="button"
            onClick={() => setReady(true)}
            className="w-full py-3 rounded-2xl font-bold text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-90 transition"
          >
            Yes, I'm ready
          </button>

          <p className="text-xs text-slate-500">
            You can also just say "Yes".
          </p>
        </div>
      </div>
    );
  }

  if (phase === "loading") {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center relative overflow-hidden font-sans">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-indigo-500/20 rounded-full blur-[120px] pointer-events-none" />

        <div className="bg-slate-900/60 border border-slate-800/80 backdrop-blur-2xl p-10 rounded-3xl text-center max-w-sm shadow-2xl relative z-10">
          <div className="w-16 h-16 border-4 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin mx-auto mb-6" />

          <h2 className="text-xl font-bold text-white mb-2">
            Preparing Session
          </h2>

          <p className="text-xs text-slate-400 font-mono">
            Starting interview...
          </p>

          <p className="text-[10px] text-slate-500 mt-3">
            Camera and monitoring can be enabled from the interview screen.
          </p>
        </div>
      </div>
    );
  }

  /*
   * ============================================================
   * ERROR
   * ============================================================
   */

  if (phase === "error") {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-6">
        <div className="max-w-lg w-full bg-slate-900/80 border border-rose-500/30 backdrop-blur-2xl rounded-3xl p-8 shadow-2xl space-y-4">
          <div className="w-12 h-12 bg-rose-500/10 border border-rose-500/20 text-rose-400 rounded-2xl flex items-center justify-center font-bold text-xl">
            ⚠️
          </div>

          <h2 className="text-xl font-bold text-white">
            Interview Error
          </h2>

          <p className="text-slate-300 text-sm leading-relaxed">
            {error}
          </p>

          <button
            onClick={() =>
              window.location.reload()
            }
            className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-all cursor-pointer border border-slate-700"
          >
            Retry Connection
          </button>
        </div>
      </div>
    );
  }

  /*
   * ============================================================
   * TERMINATED
   * ============================================================
   */

  if (phase === "terminated") {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-slate-900/80 border border-rose-500/30 backdrop-blur-2xl p-8 rounded-3xl text-center space-y-4 shadow-2xl">
          <div className="w-16 h-16 bg-rose-500/10 border border-rose-500/30 text-rose-400 rounded-2xl flex items-center justify-center text-3xl mx-auto">
            ⚠
          </div>

          <h1 className="text-2xl font-bold text-white">
            Interview Ended
          </h1>

          <p className="text-slate-400 text-sm leading-relaxed">
            The interview was ended because the interview monitoring condition was violated.
          </p>

          <p className="text-xs text-slate-500">
            Please contact the interviewer if you believe this happened by mistake.
          </p>
        </div>
      </div>
    );
  }

  /*
   * ============================================================
   * COMPLETED
   * ============================================================
   */

  if (phase === "completed") {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-6 relative overflow-hidden font-sans">
        <div className="max-w-md w-full bg-slate-900/80 border border-emerald-500/30 backdrop-blur-2xl p-8 rounded-3xl text-center space-y-4 shadow-2xl">
          <div className="w-16 h-16 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-2xl flex items-center justify-center text-3xl mx-auto">
            ✓
          </div>

          <h1 className="text-2xl font-bold text-white">
            Thank You for the Interview!
          </h1>

          <p className="text-slate-300 text-base font-semibold">
            Your interview is completed.
          </p>

          <p className="text-slate-400 text-sm leading-relaxed">
            Your answers were submitted successfully and will be reviewed by the interviewer.
          </p>

          <div className="text-left rounded-2xl border border-slate-800 bg-slate-950/60 p-4 text-sm text-slate-300 space-y-2">
            <p>
              <b className="text-emerald-300">Selected?</b> Our team will contact you.
            </p>
            <p>
              <b className="text-slate-100">Not selected?</b> You will receive an email.
            </p>
            <p className="text-xs text-slate-500">
              A confirmation email is on its way to you now.
            </p>
          </div>

          <button
            type="button"
            onClick={() => navigate("/dashboard")}
            className="w-full py-3 rounded-2xl font-bold text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-90 transition"
          >
            Back to dashboard
          </button>
        </div>
      </div>
    );
  }

  /*
   * ============================================================
   * MAIN UI
   * ============================================================
   */

  const lastAiIndex = chatLog.reduce(
    (found, m, i) => (m.role === "ai" ? i : found),
    -1
  );

  const previousMessages = chatLog.filter(
    (_m, i) => i !== lastAiIndex
  );

  const questionText = currentQuestion?.question || "";
  const typing = typedLength < questionText.length;

  const assistantStatus = processing
    ? "Evaluating..."
    : isSpeaking
    ? "Speaking..."
    : isListening
    ? "Listening..."
    : "Your turn";

  const TOTAL_QUESTIONS = 5;

  const progress = Math.round(
    (Math.min(Number(questionNumber) || 1, TOTAL_QUESTIONS) /
      TOTAL_QUESTIONS) *
      100
  );

  const statusColor = (value, good, bad) =>
    bad
      ? "text-rose-400"
      : good
      ? "text-emerald-400"
      : "text-slate-400";

  const monitorRows = [
    {
      label: "Camera",
      value: cameraEnabled ? "On" : "Off",
      good: cameraEnabled,
    },
    {
      label: "Face detection",
      value: faceStatus,
      good: faceStatus === "Face detected",
      bad:
        faceStatus === "No face detected" ||
        faceStatus === "Multiple faces detected",
    },
    {
      label: "Eye / eyeball",
      value: eyeStatus,
      good:
        eyeStatus === "Eyes focused" || eyeStatus === "Eyes open",
      bad:
        eyeStatus === "Looking away" ||
        eyeStatus === "Looking down" ||
        eyeStatus === "Eyes closed",
    },
    ...(policy.phone
      ? [
          {
            label: "Phone",
            value: phoneStatus,
            good: phoneStatus === "No phone detected",
            bad: phoneStatus === "Phone detected",
          },
        ]
      : []),
  ];

  return (
    <div className="h-screen bg-[#1a2338] text-slate-100 font-sans overflow-hidden">
      {/* CAMERA REQUIRED (only when the interviewer turned monitoring on) */}
      {policy.loaded && policy.enabled && !cameraEnabled && (
        <div className="fixed inset-0 z-50 bg-[#1a2338]/95 flex items-center justify-center p-6">
          <div className="max-w-md w-full bg-[#1c2740] border border-slate-600 rounded-xl p-8 text-center space-y-4">
            <h2 className="text-xl font-bold text-white">
              Camera required
            </h2>

            <p className="text-sm text-slate-400 leading-relaxed">
              {cameraBlocked
                ? "The interviewer requires camera monitoring for this interview. Please allow camera access in your browser, then try again."
                : "Starting your camera. Please allow access if your browser asks."}
            </p>

            {cameraBlocked && (
              <button
                type="button"
                onClick={startMonitoring}
                className="w-full py-3 rounded-lg font-semibold text-white bg-slate-600 hover:bg-slate-500"
              >
                Allow camera and continue
              </button>
            )}
          </div>
        </div>
      )}

      <div className="h-full grid grid-cols-1 lg:grid-cols-[60%_40%]">
        {/* ================= LEFT ================= */}
        <section className="h-full flex flex-col gap-3 p-4 md:p-8 min-h-0 overflow-y-auto">
          {/* LOGO */}
          <div className="h-[56px] shrink-0 rounded-lg border border-[#2a3550] bg-[#1c2740] flex items-center justify-center gap-2 text-xl font-black">
            <span className="text-[#ea5b24]">VOLK</span>
            <span>Ai</span>
            <span className="text-sky-400">HR</span>
          </div>

          {/* VIDEO */}
          <div className="relative flex-1 min-h-[220px] rounded-lg border border-[#2a3550] bg-[#0f1626] overflow-hidden">
            {cameraEnabled ? (
              <video
                ref={attachVideo}
                autoPlay
                playsInline
                muted
                onLoadedMetadata={(event) => {
                  event.currentTarget.play().catch(() => {});
                }}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-slate-500 text-sm">
                Camera is off
              </div>
            )}

            {cameraEnabled && (
              <span className="absolute top-3 left-3 px-2 py-1 rounded bg-black/60 text-[10px] font-semibold">
                ● LIVE
              </span>
            )}
          </div>

          {/* INTERVIEWER + MONITORING */}
          <div className="shrink-0 grid grid-cols-1 sm:grid-cols-[180px_1fr] gap-3">
            <div className="rounded-lg border border-[#2a3550] bg-[#1c2740] p-4 flex flex-col items-center justify-center gap-2">
              <div
                className={`w-14 h-14 rounded-full flex items-center justify-center text-2xl bg-[#2a3550] border-2 ${
                  isSpeaking
                    ? "border-[#ea5b24] animate-pulse"
                    : "border-[#3a4660]"
                }`}
              >
                🤖
              </div>
              <div className="text-sm font-bold">AI Interviewer</div>
              <div className="text-[11px] text-slate-400">
                {assistantStatus}
              </div>
            </div>

            <div className="rounded-lg border border-[#2a3550] bg-[#1c2740] p-4">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                Monitoring
              </div>

              <div className="space-y-1.5">
                {monitorRows.map((row) => (
                  <div
                    key={row.label}
                    className="flex items-center justify-between text-xs"
                  >
                    <span className="text-slate-400">{row.label}</span>
                    <span
                      className={`font-semibold ${statusColor(
                        row.value,
                        row.good,
                        row.bad
                      )}`}
                    >
                      {row.value}
                    </span>
                  </div>
                ))}
              </div>

              {!policy.enabled && (
                <p className="mt-2 text-[10px] text-slate-500 leading-relaxed">
                  Face / eye detection is OFF because the interviewer has not
                  turned monitoring on for this interview.
                </p>
              )}
            </div>
          </div>

          {/* CONTROLS */}
          <div className="shrink-0 rounded-lg border border-[#2a3550] bg-[#1c2740] px-4 py-3 flex flex-wrap items-center justify-center gap-3">
            {voiceSupported && (
              <button
                type="button"
                disabled={processing || phase === "followup-confirmation"}
                onClick={isListening ? stopListening : startListening}
                className={`px-4 py-2 rounded-md text-sm disabled:opacity-50 ${
                  isListening
                    ? "bg-rose-500/30 text-rose-200"
                    : "bg-slate-600/60 hover:bg-slate-600"
                }`}
              >
                🎤 {isListening ? "Stop Recording" : "Start Recording"}
              </button>
            )}

            <button
              type="button"
              disabled={policy.enabled}
              onClick={toggleCamera}
              className="px-4 py-2 rounded-md text-sm bg-slate-600/60 hover:bg-slate-600 disabled:opacity-60 disabled:cursor-not-allowed"
            >
              📹{" "}
              {cameraEnabled
                ? policy.enabled
                  ? "Video On"
                  : "Stop Video"
                : "Start Video"}
            </button>

            {voiceSupported && (
              <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={autoSubmitVoice}
                  onChange={(event) =>
                    setAutoSubmitVoice(event.target.checked)
                  }
                  className="w-3.5 h-3.5"
                />
                Auto submit voice
              </label>
            )}
          </div>

          {policy.enabled && (
            <p className="shrink-0 text-[10px] text-slate-500 text-center leading-relaxed">
              Keep your face visible, keep phones and notes away, look at
              the screen and stay on this page. Leaving the page ends the
              interview.
            </p>
          )}
        </section>

        {/* ================= RIGHT ================= */}
        <section className="h-full min-h-0 flex flex-col border-l border-[#2a3550]">
          <div className="h-[64px] shrink-0 flex items-center justify-center">
            <h1 className="text-xl font-bold text-white">
              AI Interview Assistant 🤖
            </h1>
          </div>

          <div className="flex-1 min-h-0 mx-5 mb-5 rounded-lg border border-[#2a3550] bg-[#1c2740] flex flex-col p-4 gap-3">
            {/* progress */}
            <div className="shrink-0 flex items-center gap-3 text-xs text-slate-400">
              <span>
                Question {Math.min(Number(questionNumber) || 1, TOTAL_QUESTIONS)} of{" "}
                {TOTAL_QUESTIONS}
              </span>
              <div className="flex-1 h-1.5 rounded bg-[#141c2e] overflow-hidden">
                <div
                  className="h-full bg-slate-400 transition-all duration-500"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <span className="font-mono">⏱ {formatTime(elapsedSeconds)}</span>
            </div>

            {/* current question (text appears with the voice) */}
            <div className="shrink-0 min-h-[96px] rounded-md bg-[#141c2e] px-5 py-4 text-center text-[15px] leading-relaxed">
              {currentQuestion?.is_follow_up && (
                <div className="text-[10px] font-bold uppercase tracking-wider text-amber-400 mb-1">
                  Follow-up question
                </div>
              )}
              Interviewer: "{questionText.slice(0, typedLength)}
              {typing ? "▍" : ""}"
            </div>

            {/* status + repeat */}
            <div className="shrink-0 flex justify-end items-center gap-2">
              <span className="px-4 py-2 rounded-md bg-[#141c2e] text-sm">
                {assistantStatus}
              </span>
            </div>

            <h3 className="shrink-0 text-[#ea5b24] font-bold text-sm">
              Previous Questions:
            </h3>

            {/* transcript */}
            <div className="flex-1 min-h-0 overflow-y-auto space-y-3 pr-1">
              {previousMessages.map((m, i) =>
                m.role === "you" ? (
                  <div key={i} className="flex justify-end">
                    <div className="max-w-[85%] rounded-lg border border-[#3a4660] bg-[#202c47] px-4 py-2.5 text-sm">
                      <b>You:</b> {m.text}
                    </div>
                  </div>
                ) : (
                  <div key={i} className="flex justify-start">
                    <div className="max-w-[85%] rounded-lg border border-[#3a4660] bg-[#202c47] px-4 py-2.5 text-sm leading-relaxed">
                      <b>Interviewer:</b> {m.text}
                    </div>
                  </div>
                )
              )}

              <div ref={chatEndRef} />
            </div>

            {error && (
              <div className="shrink-0 p-3 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs">
                {error}
              </div>
            )}

            {/* follow-up offer OR typed answer */}
            {phase === "followup-confirmation" ? (
              <div className="shrink-0 space-y-3">
                <p className="text-sm text-slate-300 text-center">
                  Would you like a follow-up question?{" "}
                  {isSpeaking
                    ? "(AI is asking...)"
                    : isListening
                    ? '(Listening... say "yes" or "no")'
                    : '(Say "yes" or "no", or use the buttons)'}
                </p>

                <div className="grid grid-cols-2 gap-3">
                  <button
                    disabled={processing}
                    onClick={handleFollowUpYes}
                    className="py-3 rounded-md bg-emerald-700 hover:bg-emerald-600 text-white font-semibold text-sm disabled:opacity-50"
                  >
                    {processing ? "Processing..." : "YES — Ask Follow-up"}
                  </button>

                  <button
                    disabled={processing}
                    onClick={handleFollowUpNo}
                    className="py-3 rounded-md bg-slate-700 hover:bg-slate-600 text-slate-100 font-semibold text-sm disabled:opacity-50"
                  >
                    NO — Next Question
                  </button>
                </div>
              </div>
            ) : (
              <div className="shrink-0 flex gap-2">
                <input
                  value={answer}
                  onChange={(event) => setAnswer(event.target.value)}
                  onKeyDown={(event) => {
                    if (
                      event.key === "Enter" &&
                      answer.trim() &&
                      !processing
                    ) {
                      submitAnswerWithText(answer);
                    }
                  }}
                  disabled={processing}
                  placeholder="Speak, or type your answer here..."
                  className="flex-1 px-4 py-3 rounded-md bg-[#141c2e] border border-[#2a3550] focus:border-slate-400 outline-none text-sm placeholder-slate-500 disabled:opacity-50"
                />

                <button
                  disabled={processing || !answer.trim()}
                  onClick={() => submitAnswerWithText(answer)}
                  className="px-5 rounded-md bg-slate-600 hover:bg-slate-500 text-white font-semibold text-sm disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  {processing ? "..." : "Send"}
                </button>
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
